﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades
{
    public static class GuardaString
    {
        public static bool Guardar(this string texto, string archivo)
        {
            string direccion = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\" + archivo;

            try
            {
                if (File.Exists(direccion))
                {
                    using (StreamWriter sw = new StreamWriter(direccion, true))
                    {
                        sw.WriteLine(texto);
                    }
                }
                else
                {
                    using (StreamWriter sw = new StreamWriter(direccion, false))
                    {
                        sw.WriteLine(texto);
                    }
                }
            }
            catch (Exception e)
            {

                return false;

            }
            return true;
        }
    }
}
