﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestsUnitarios
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void CorreoNoNull()
        {
            Correo c = new Correo();
            Assert.IsNotNull(c);
        }

        [TestMethod]
        public void PaqueteMismoID()
        {
            Paquete p1 = new Paquete("Avellaneda", "11111");
            Paquete p2 = new Paquete("Capital", "11111");
            Correo c = new Correo();

            try
            {
                c += p1;
                c += p2;
                Assert.Fail("Error en Test PaqueteMismoID");
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(TrackingIdRepetidoException));
            }
        }

    }
}
