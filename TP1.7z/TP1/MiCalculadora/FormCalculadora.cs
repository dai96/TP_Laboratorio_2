﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;

namespace MiCalculadora
{
    public partial class FormCalculadora : Form
    {
        private void Limpiar()
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
            cmbOperador.Text = "";
            lbResultado.Text = "";
            btnConvertirABinario.Enabled = false;
            btnConvertirADecimal.Enabled = false;
        }
        private static double Operar(string numero1, string numero2, string operador)
        {
            Numero n1 = new Numero(numero1);
            Numero n2 = new Numero(numero2);
            return Calculadora.Operar(n1, n2, operador);
        }
        public FormCalculadora()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            double operacion = Operar(txtNumero1.Text, txtNumero2.Text, cmbOperador.Text);
            lbResultado.Text = operacion.ToString();
            this.btnConvertirABinario.Enabled = true;
        }

        private void BtnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormCalculadora_Load(object sender, EventArgs e)
        {
            this.cmbOperador.Items.Add("/");
            this.cmbOperador.Items.Add("+");
            this.cmbOperador.Items.Add("-");
            this.cmbOperador.Items.Add("*");
        }

        private void BtnConvertirABinario_Click(object sender, EventArgs e)
        {
            lbResultado.Text = Numero.DecimalBinario(double.Parse(lbResultado.Text));
            this.btnConvertirADecimal.Enabled = true;
            this.btnConvertirABinario.Enabled = false;

        }

        private void CmbOperador_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void BtnLimpiar_Click(object sender, EventArgs e)
        {
            this.Limpiar();
        }

        private void BtnConvertirADecimal_Click(object sender, EventArgs e)
        {
            lbResultado.Text = Numero.BinarioDecimal(lbResultado.Text);
            btnConvertirABinario.Enabled = true;
            btnConvertirADecimal.Enabled = false;
        }
    }
}
