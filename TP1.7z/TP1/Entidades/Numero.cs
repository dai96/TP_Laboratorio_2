﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Numero
    {
        private double numero;

        private string SetNumero
        {
            set { this.numero = ValidarNumero(value); }
        }
        public static string BinarioDecimal(string binario)
        {
            int l = binario.Length;
            int i;
            double rtn = 0;

            for (i = 1; i <= l; i++)
            {

                byte n = byte.Parse(binario.Substring(l - i, 1));
                if (n == 1)
                {
                    rtn += System.Math.Pow(2, i - 1);
                }

            }
            if (rtn == 0)
            {
                return "Valor Invalido";
            }
            return rtn.ToString();
        }
        public static string DecimalBinario(double numero)
        {
            string stg = "Valor Invalido";
            if (numero > 0)
            {
                stg = "";
                while (numero > 0)
                {
                    if (numero % 2 == 0)
                    {
                        stg = "0" + stg;

                    }
                    else
                    {
                        stg = "1" + stg;

                    }
                    numero = (int)numero / 2;
                }
            }

            return stg;
        }
        public static string DecimalBinario(string numero)
        {
            return DecimalBinario(double.Parse(numero));
        }
        public Numero() : this(0)
        {
        }
        public Numero(double numero) : this(numero.ToString())
        {
        }
        public Numero(string strNumero)
        {
            this.SetNumero = strNumero;
        }
        public static double operator -(Numero n1, Numero n2)
        {
            return n1.numero - n2.numero;
        }
        public static double operator *(Numero n1, Numero n2)
        {
            return n1.numero * n2.numero;
        }
        public static double operator /(Numero n1, Numero n2)
        {
            if (n2.numero == 0)
            {
                return double.MinValue;
            }
            return n1.numero / n2.numero;
        }
        public static double operator +(Numero n1, Numero n2)
        {
            return n1.numero + n2.numero;
        }
        private double ValidarNumero(string strNumero)
        {
            double numero;
            if (double.TryParse(strNumero, out numero))
            {
                return numero;
            }
            return 0;
        }

    }
}
