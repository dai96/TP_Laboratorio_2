﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca
{
    sealed class Alumno: Universitario
    {
        private EClases claseQueToma;
        private EEstadoCuenta estadoCuenta;

        public enum EEstadoCuenta
        {
            AlDia,
            Deudor,
            Becado
        }

        public Alumno()
        { }
        public Alumno(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad):base(legajo,nombre,apellido,dni,nacionalidad)
        { }

        public string MostrarDatos()
        { }
        public static bool operator ==(Alumno a, Eclase clase)
        {
            return true;
        }
        public static bool operator !=(Alumno a, Eclase clase)
        {
            return true;
        }
        public string ParticiparEnClase()
        { }
        public string ToString()
        { return ""; }
    }
}
