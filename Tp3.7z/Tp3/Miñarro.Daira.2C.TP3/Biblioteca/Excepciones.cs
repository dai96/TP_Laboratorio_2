﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca
{
    public class ArchivosException:Exception
    {
    }
    public class DniInvalidoException : Exception
    {
    }
    public class NacionalidadInvalidaException : Exception
    {
    }
    public class SinProfesorException : Exception
    {
    }
    public class AlumnoRepetidoException : Exception
    {

    }
}
