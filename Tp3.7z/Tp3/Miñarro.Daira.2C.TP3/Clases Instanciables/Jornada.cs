using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Exepciones;

namespace Clases_Instanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private Universidad.EClases clase;
        private Profesor instructor;

        public List<Alumno> Alumnos
        {
            get { return this.alumnos; }
            set { this.alumnos = value; }
        }
        public Universidad.EClases Clase
        {
            get { return this.clase; }
            set { this.clase = value; }
        }
        public Profesor Instructor
        {
            get { return this.instructor; }
            set { this.instructor = value; }
        }

        public bool Guardar(Jornada jornada)
        {


        }
        private Jornada()
        {
            this.Alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clases, Profesor instructor):this()
        {
            this.Clase = clase;
            this.instructor = instructor;
            //this.Instructor = instructor;
        }
        public string Leer()
        { }

        public static bool operator ==(Jornada j, Alumno a)
        {
            foreach(Alumno item in j.alumnos)
            {
                if(item==a)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }
        public static Jornada operator +(Jornada j, Alumno a)
        {
           if (j!=a)
            {
                j.alumnos.Add(a);
                return j;
            }
           else
            {
                throw new AlumnoRepetidoException();
            }
 
        }
        public override string ToString()
        { return ""; }

    }
}
