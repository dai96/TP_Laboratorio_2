﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clases_Abstractas;

namespace Clases_Instanciables
{
    public sealed class Alumno : Universitario
    {
        private Universidad.EClases claseQueToma;
        private EEstadoCuenta estadoCuenta;

        public enum EEstadoCuenta
        {
            AlDia,
            Deudor,
            Becado
        }

        public Alumno()
        { }
        public Alumno(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma) : base(legajo, nombre, apellido, dni, nacionalidad)
        {
            this.claseQueToma = claseQueToma;
        }
        public Alumno(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma,EEstadoCuenta estadoCuenta) : this(legajo, nombre, apellido, dni, nacionalidad,claseQueToma)
        {
            this.estadoCuenta = estadoCuenta;
        }

        protected override string MostrarDatos()
        {
            StringBuilder stg = new StringBuilder();
            stg.Append(base.MostrarDatos());
            stg.AppendFormat("{0}{1}", this.claseQueToma,this.estadoCuenta);
            return stg.ToString();
        }
        public static bool operator ==(Alumno a, Universidad.EClases clase)
        {
            if (!(a!=clase) && a.estadoCuenta!=EEstadoCuenta.Deudor)
            {
                return true;
            }
            return false;
        }
        public static bool operator !=(Alumno a, Universidad.EClases clase)
        {
            if (a.claseQueToma != clase)
            {
                return true;
            }
            return false;
        }
        protected override string ParticiparEnClase()
        {
            StringBuilder stg = new StringBuilder();
            stg.AppendFormat("TOMA CLASE DE {0}", this.claseQueToma);
            return stg.ToString();
        }
        public override string ToString()
        {
            return this.MostrarDatos();
        }
    }
}
