﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exepciones
{
    public class DniInvalidoException : Exception
    {
        private string mensajeBase;

        public DniInvalidoException():this("Dni incorrecto",null)
        { }
        public DniInvalidoException(Exception e) : this("Dni incorrecto",e)
        { }
        public DniInvalidoException(string message) : this(message, null)
        { }
        public DniInvalidoException(string message, Exception e) : base(message,e)
        { }

    }
}
