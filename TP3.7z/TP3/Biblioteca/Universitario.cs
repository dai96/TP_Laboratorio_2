﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca
{
    abstract class Universitario:Persona
    {
        private int legajo;

        public bool Equals(object obj)
        {
            return true;
        }
        protected string MostrarDatos()
        {
            return "";
        }
        public static bool operator ==(Universitario pg1, Universitario pg2)
        {
            return true;
        }
        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            return true;
        }
        protected string ParticiparEnClase()
        {
            return "";
        }

        public Universitario()
        { }

        public Universitario(int legajo, string nombre, string apellido, string dni, ENacionalidad nacionalidad):base(nombre,apellido,dni,nacionalidad)
        { }

    }
}
