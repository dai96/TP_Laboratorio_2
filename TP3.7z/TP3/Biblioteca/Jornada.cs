﻿}using System;
using System.Collections.Generic;
using System.Text;

namespace Biblioteca
{
    class Jornada
    {
        private List<Alumno> alumnos;
        private EClases clase;
        private Profesor instructor;

        public List<Alumno> Alumnos
        {
            get { return; }
            set { this.apellido = value; }
        }
        public EClases Clase
        {
            get { return; }
            set { this.apellido = value; }
        }
        public Profesor Instructor
        {
            get { return; }
            set { this.apellido = value; }
        }

        public bool Guardar(Jornada jornada)
        { }
        protected Jornada()
            {}
        public Jornada(EClases clases, Profesor instructor)
        {

        }
        public string Leer()
        { }

        public static bool operator ==(Jornada j, Alumno a)
        {
            return true;
        }
        public static bool operator !=(Jornada j, Alumno a)
        {
            return true;
        }
        public static Jornada operator +(Jornada j, Alumno a)
        {
            return j;
        }
        public string ToString()
        { return ""; }

    }
}
