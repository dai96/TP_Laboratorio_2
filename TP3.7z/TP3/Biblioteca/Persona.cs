﻿using System;

namespace Biblioteca
{
    abstract class Persona
    {
        private string apellido;
        private int dni;
        private ENacionalidad nacionalidad;
        private string nombre;

        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
        public string Apellido
        {
            get {return this.apellido; }
            set { this.apellido = value; }
        }
        public int Dni
        {
            get { return this.dni; }
            set { this.dni = value; }
        }
        public ENacionalidad Nacionalidad
        {
            get { return this.nacionalidad; }
            set { this.nacionalidad = value; }
        }
        public string Nombre
        {
            get { return this.nombre; }
            set { this.nombre = value; }
        }
        public string StringToDNI
        {
            set { this.apellido = value; }
        }

        public Persona()
        { 
        }
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
        }
        public Persona(string nombre, string apellido,int dni ,ENacionalidad nacionalidad):this(nombre,apellido,nacionalidad)
        {
            this.dni = dni;
        }
        public Persona(string nombre, string apellido,string dni ,ENacionalidad nacionalidad):this(nombre,apellido,nacionalidad)
        {
            this.StringToDNI = dni;
        }
        public string ToString()
        { return ""; }
        

        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            return 1;
        }
        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            return 1;
        }
        private string ValidarNombre(string dato)
        {
            return "";
        }
    }
}
