﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Exepciones;
using Clases_Abstractas;
using Clases_Instanciables;

namespace TestTP3
{
    [TestClass]
    public class TestTP3
    {
        [TestMethod]
        public void TestDNIInvalidoException()//ESTE TEST ES EL QUE VALIDA NUMEROS
        {
            try
            {
                Alumno a2 = new Alumno(2, "Juana", "Martinez", "0", Clases_Abstractas.Persona.ENacionalidad.Extranjero, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.Deudor);
            }
            catch (DniInvalidoException)
            { Assert.IsTrue(true); }
        }
        [TestMethod]
        public void TestAlumnoRepetidoException()
        {
            try
            {
                Universidad uni = new Universidad();
                Alumno a2 = new Alumno(2, "Juana", "Martinez", "12234458", Clases_Abstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.Deudor);
                Alumno a3 = new Alumno(2, "Juana", "Martinez", "12234458", Clases_Abstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.Deudor);
                uni += a2;
                uni += a3;
            }
            catch (AlumnoRepetidoException)
            { Assert.IsTrue(true); }
        }
        [TestMethod]
        public void TestNacionalidadException()
        {
            try
            {
                Alumno a2 = new Alumno(2, "Juana", "Martinez", "1", Clases_Abstractas.Persona.ENacionalidad.Extranjero, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.Deudor);
            }
            catch (NacionalidadInvalidaException)
            { Assert.IsTrue(true); }
        }
        [TestMethod]
        public void AlumnoNoNull()
        {
            Alumno a2 = new Alumno(2, "Juana", "Martinez", "12234458", Clases_Abstractas.Persona.ENacionalidad.Argentino, Universidad.EClases.Laboratorio, Alumno.EEstadoCuenta.Deudor);
            Assert.IsNotNull(a2);
        }
    }
}
