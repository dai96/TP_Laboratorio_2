﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Xml.Serialization;
using Exepciones;

namespace Archivos
{
    public class Xml<T>
    {
        public bool Guardar(string archivo, T datos)
        {
            try
            {
                using (TextWriter writer = new StreamWriter(archivo))
                {
                    XmlSerializer xml = new XmlSerializer(typeof(T));
                    xml.Serialize(writer, datos);
                    return true;
                }
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }
            
        }


        public bool Leer(string archivo, out T datos)
        {
            try
            {
                using (TextReader reader = new StreamReader(archivo))
                {
                    XmlSerializer xml = new XmlSerializer(typeof(T));
                    datos = (T)xml.Deserialize(reader);
                    return true;
                }
            }
            catch (Exception e)
            {
                throw new ArchivosException(e);
            }
            
        }
    }
}
