using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Exepciones;
using Archivos;

namespace Clases_Instanciables
{
    public class Universidad
    {
        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesores;

        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }

        public List<Alumno> Alumnos
        {
            get { return this.alumnos; }
            set { this.alumnos = value; }
        }
        public List<Profesor> Instructores
        {
            get { return this.profesores; }
            set { this.profesores = value; }
        }
        public List<Jornada> Jornadas
        {
            get { return this.jornada; }
            set { this.jornada = value; }
        }
        public Jornada this[int i]
        {
            get { return this.Jornadas[i]; }
            set { this.Jornadas[i] = value; }
        }

        public static bool Guardar(Universidad uni)
        {
            Xml<Universidad> xml = new Xml<Universidad>();
            return xml.Guardar("Universidad.xml", uni);
        }
        public static Universidad Leer()
        {
            Universidad retorno = new Universidad();
            Xml<Universidad> xml = new Xml<Universidad>();
            xml.Leer("Universidad.xml", out retorno);
            return retorno;
        }
        private static string MostrarDatos(Universidad uni)
        {
            StringBuilder stg = new StringBuilder();
            stg.AppendLine("JORNADA:");
            foreach (Jornada item in uni.Jornadas)
            {
                stg.Append(item.ToString());
            }
            return stg.ToString();
        }
        public static bool operator ==(Universidad g, Alumno a)
        {
            foreach (Alumno item in g.alumnos)
            {
                if (item == a)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator ==(Universidad g, Profesor i)
        {
            foreach (Profesor item in g.profesores)
            {
                if (item == i)
                {
                    return true;
                }
            }
            return false;
        }
        public static Profesor operator ==(Universidad g, EClases clase)
        {
            foreach (Profesor item in g.profesores)
            {
                if (item == clase)
                {
                    return item;
                }
            }
            throw new SinProfesorException();
        }
        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g == a);
        }
        public static bool operator !=(Universidad g, Profesor i)
        {

            return !(g == i);
        }
        public static Profesor operator !=(Universidad g, EClases clase)
        {

            return (g == clase);
        }
        public static Universidad operator +(Universidad g, EClases clase)
        {

            Profesor profesor = (g == clase);
            Jornada aux = new Jornada(clase, profesor);
            foreach (Alumno item in g.Alumnos)
            {
                if (item == clase)
                {
                    aux += item;
                }
            }
            g.Jornadas.Add(aux);
            return g;
        }
        public static Universidad operator +(Universidad g, Alumno a)
        {
            if (g != a)
            {
                g.Alumnos.Add(a);
            }
            else
            {
                throw new AlumnoRepetidoException();
            }
            return g;
        }
        public static Universidad operator +(Universidad g, Profesor i)
        {
            if (g != i)
            {
                g.profesores.Add(i);
            }

            return g;
        }
        public override string ToString()
        {
            return MostrarDatos(this);
        }
        public Universidad()
        {
            this.Alumnos = new List<Alumno>();
            this.Instructores = new List<Profesor>();
            this.Jornadas = new List<Jornada>();
        }

    }
}
