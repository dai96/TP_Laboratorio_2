﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using Clases_Abstractas;

namespace Clases_Instanciables
{
    public sealed class Profesor : Universitario
    {
        private Queue<Universidad.EClases> clasesDelDia;
        private static Random random;

        private void _randomClases()
        {
            Thread.Sleep(150);
            this.clasesDelDia.Enqueue(((Universidad.EClases)Profesor.random.Next(0, 4)));
            this.clasesDelDia.Enqueue(((Universidad.EClases)Profesor.random.Next(0, 4)));
        }
        protected override string MostrarDatos()
        {
            StringBuilder stg = new StringBuilder();
            stg.Append(base.MostrarDatos());
            stg.AppendFormat(this.ParticiparEnClase());
            return stg.ToString();
        }
        public static bool operator ==(Profesor i, Universidad.EClases clase)
        {
            foreach (Universidad.EClases item in i.clasesDelDia)
            {
                if (item == clase)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Profesor i, Universidad.EClases clase)
        {
            return !(i == clase);
        }
        protected override string ParticiparEnClase()
        {
            StringBuilder stg = new StringBuilder();
            stg.AppendFormat("CLASES DEL DIA:\n");
            foreach (Universidad.EClases item in this.clasesDelDia)
            {
                stg.AppendFormat("{0}\n", item);
            }
            return stg.ToString();
        }

        public Profesor()
        { }

        static Profesor()
        {
            Profesor.random = new Random();
        }

        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad)
        {
            this.clasesDelDia = new Queue<Universidad.EClases>();
            this._randomClases();
        }


        public override string ToString()
        { return this.MostrarDatos(); }
    }
}
