using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Archivos;
using Exepciones;

namespace Clases_Instanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private Universidad.EClases clase;
        private Profesor instructor;

        public List<Alumno> Alumnos
        {
            get { return this.alumnos; }
            set { this.alumnos = value; }
        }
        public Universidad.EClases Clase
        {
            get { return this.clase; }
            set { this.clase = value; }
        }
        public Profesor Instructor
        {
            get { return this.instructor; }
            set { this.instructor = value; }
        }

        public static bool Guardar(Jornada jornada)
        {
            Texto texto = new Texto();
            return texto.Guardar((AppDomain.CurrentDomain.BaseDirectory + @"\Jornadas.txt"), jornada.ToString());
        }
        private Jornada()
        {
            this.Alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clases, Profesor instructor) : this()
        {
            this.Clase = clase;
            this.Instructor = instructor;

        }
        public static string Leer()
        {
            Texto texto = new Texto();
            string rtn;
            texto.Leer((AppDomain.CurrentDomain.BaseDirectory + @"\Jornadas.txt"), out rtn);
            return rtn;
        }

        public static bool operator ==(Jornada j, Alumno a)
        {
            foreach (Alumno item in j.alumnos)
            {
                if (item == a)
                {
                    return true;
                }
            }
            return false;
        }
        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }
        public static Jornada operator +(Jornada j, Alumno a)
        {
            if (j != a)
            {
                j.alumnos.Add(a);
                return j;
            }
            else
            {
                throw new AlumnoRepetidoException();
            }

        }
        public override string ToString()
        {
            StringBuilder stg = new StringBuilder();
            stg.AppendFormat("CLASES DE {0} POR {1}", this.clase, this.instructor.ToString());
            stg.AppendFormat("\nALUMNOS:");
            foreach (Alumno item in this.alumnos)
            {
                stg.AppendFormat("\n{0}", item);
            }
            return stg.ToString();
        }

    }
}
